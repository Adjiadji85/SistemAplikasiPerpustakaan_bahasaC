#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define cls() system("cls")
#define ENTER 13
#define TAB 9
#definr BKSP 8
#include <windows.h>
#include <string.h>

void login(),gotoab(),menu(),create(),read(),update(),deleted(),edit(),searching(),history(),
sorting(),menu8a(),prSearch(),copy_all(),kembali(),
bsort_buku(),bsort_penerbit(),bsort_pengarang(),bsort_tahun();
int n = 0, search();
COORD coord = {0,0};

struct daftar{
    char buku[50];
    char id[10];
    char penerbit[50];
    char pengarang[50];
    char tahun[10];

    struct daftar *next;
};

struct daftar *head = NULL, *node = NULL, *curr = NULL;

struct hist{
    char aktivitas[100];
    struct hist *next;
};

struct hist *headhist = NULL, *nodehist, *currhist,*datahist;

typedef struct{
    char buku[50];
    char id[10];
    char penerbit[50];
    char pengarang[50];
    char tahun[10];
} s_buku;

s_buku s_data[100];
void bsort_id(s_buku list[], int s);
void bsort_buku(s_buku list[], int s);
void bsort_penerbit(s_buku list[], int s);
void bsort_pengarang(s_buku list[], int s);
void bsort_tahun(s_buku list[], int s);

int main(){
    login();
    return 0;
}

getch();

void gotoab(int a, int b) {
    coord.X=a;
    coord.Y=b;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void login(){
    char user[6];
    char pass[100];
    int p=0;
    time_t t;
    time(&t);
    system("COLOR B");
    gotoab(34,9);printf("=======================================================");
    gotoab(34,11);printf("=======================================================");
    gotoab(34,10);printf("><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
    gotoab(34,18);printf("=======================================================");
    gotoab(34,20);printf("=======================================================");
    gotoab(34,12);printf("                                                       ");
    gotoab(34,13);printf("                                                       ");
    gotoab(34,14);printf("                                                       ");
    gotoab(34,15);printf("                                                       ");
    gotoab(34,16);printf("                                                       ");
    gotoab(34,17);printf("                                                       ");

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),15);
    gotoab(58,7);printf("MENU LOGIN");
    gotoab(35,19);printf("Data Perpustakaan");
    gotoab(41,14);printf("ID (admin      :)");
    gotoab(41,15);printf("Password (admin :));

    gotoab(34,19);printf("\t\t\t\t   %s", ctime(%t));
    gotoab(60,14);printf("%s", &user);

    gotoab(60,15);
    char ch;
    int i = 0;
    while(1){
        ch = getch();

        if(ch == ENTER || ch == TAB ){
            pass[i] = '\0';
            break;
        }else if(ch == BSKP){
            if(i > 0){
                i--;
                printf("\b\b");
            }
        }else{
            pass[i++] = ch;
            printf("*");
        }
    }

    if(strcmp(user, "admin") == 0 && strcmp(pass, "admin") == 0){
        cls();
        gotoab(5,22);
        system("COLOR 9 ");
        system("cls");
        system("COLOR B");
        menu();
    }else{
        cls();
        login();
    }
}

void kembali(){
        char enter;
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
        printf("                <<Tekan Enter untuk kembali ke menu awal>>");
        while((enter = getchar())) != '\n');
        enter = getchar();
        system("cls");
        menu();
}

int z=0;

void create(){
    int a, max;

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
    gotoab(0,0);printf("+==================================================================================================================================+");
    gotoab(0,2);printf("+==================================================================================================================================+");
    gotoab(0,10);printf("+==================================================================================================================================+");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoab(45,1);printf("Masukan Data Baru");
    gotoab(42,4);printf("Batas Makximum inpu data: 10 buku");
    gotoab(25,6);printf("Berapa banyak yang mau diinputkan ? \n");
    gotoab(60,8);scanf("%d", &max);
    cls();

    if(max > 10){
        printf("Batas maksimum 10 data!")
        exit(0);
    }

    headhist = NULL;
    head = NULL;
    for(a=0; a,max; a++){

        node = (struct daftar*) malloc(sizeof(struct daftar));

        z = 0;
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
        gotoab(0,0);printf("|================================================================================================================================|");
        gotoab(0,2);printf("|================================================================================================================================|");

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
        gotoab(40,1);printf("             Input Database             ");
        gotoab(52,3+(6*a));printf("Buku ke - %d",a+1);
        gotoab(52,3+(6*a));printf("ID Buku       :"); scanf(" %[^\n]s", &node->id);
        gotoab(52,3+(6*a));printf("Judul Buku    :"); scanf(" %[^\n]s", &node->buku);
        gotoab(52,3+(6*a));printf("Nama Penerbit :"); scanf(" %[^\n]s", &node->penerbit);
        gotoab(52,3+(6*a));printf("Nama Pengarang:"); scanf(" %[^\n]s", &node->pengarang);
        gotoab(52,3+(6*a));printf("Tahun Penerbit:"); scanf(" %[^\n]s", &node->tahun);


        if(head == NULL){
            head = node;
            curr = node;
        }

        else{
            curr->next = node;
            curr = node;
        }
    }
    curr->next = NULL;
    z += max+1;
    n +=max;

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
        gotoab(0,(6*a)+3);printf("============================================================================================================================");

        datahist = (struct hist*) malloc(sizeof(struct hist));
        char job[100];
        sprintf(job, "Admin memasukan %d data baru", max);
        sprintf(datahist->aktivitas, job);

        if(headhist == NULL){
            headhist = datahist;
            currhist = datahist;
        }else{
            currhist -> next = datahist;
            currhist = datahist;
        }
        currhist -> next = NULL;
}

void read(){
    struct daftar *ct;
    ct = (struct daftar*) malloc(sizeof(struct daftar));;
    ct = head;

    int i = 5, j;
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 6);
        gotoab(0,0);printf("|===============================================================================================================================|");
        gotoab(0,2);printf("|===============================================================================================================================|");
        gotoab(0,4);printf("|===============================================================================================================================|");

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
        gotoab(40,1);printf("            Database perpustakaan       ");
        gotoab(0,3);printf("ID Buku");
        gotoab(24,3);printf("Judul Buku");
        gotoab(47,3);printf("Nama Penerbit");
        gotoab(76,3);printf("Nama Pengarang");
        gotoab(106,3)printf("Tahun Terbit");


        while(ct != NULl){
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

                gotoab(1,i);scanf(ct->id,"%d",%j);printf("%d", j);
                gotoab(24,i);printf("%s", ct->buku);
                gotoab(47,i);printf("%s", ct->penerbit);
                gotoab(76,i);printf("%s", ct->pengarang);
                gotoab(106,i);printf("%s", ct->tahun);
                ct = ct->next;
                i++;
        }
        printf("\n");

                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 6);
            gotoab(0,i);printf("+==========================================================================================================================+");

        datahist = (struct hist*) malloc(sizeof(struct hist));
        strcpy(datahist->aktivitas, "Admin melihat database");

        if(headhist == NULL){
            headhist = datahist;
            currhist = datahist;
        }else{
            currhist -> next = datahist;
            currhist = datahist;
        }
        currhist -> next = NULL;
}

void update(){
    int a, b = 0, max;

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
    gotoab(0,0);printf("|==========================================================================================================================|");
    gotoab(0,2);printf("|==========================================================================================================================|");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoab(40,1);printf("              Tambah Data               ");
    gotoab(40,4);printf("Berapa Data yang mau ditambahkan ? ");
    gotoab(75,4);scanf("%d", &max);
    cls();

    for(a=z; a<z + max; a++){
        node = (struct daftar*) malloc(sizeof(struct daftar));

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
        gotoab(0,0);printf("|==========================================================================================================================|");
        gotoab(0,2);printf("|==========================================================================================================================|");

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
        gotoab(40,1);printf("               Tambah Data              ");
        gotoab(52,3+(6*b));printf("Buku ke - %d",a);
        gotoab(52,4+(6*b));printf("ID buku         :"); scanf(" %[^\n]s", &node->id);
        gotoab(52,5+(6*b));printf("Judul Buku      :"); scanf(" %[^\n]s", &node->buku);
        gotoab(52,6+(6*b));printf("Nama Penerbit   :"); scanf(" %[^\n]s", &node->penerbit);
        gotoab(52,7+(6*b));printf("Nama Pengarang  :"); scanf(" %[^\n]s", &node->pengarang);
        gotoab(52,8+(6*b));printf("Tahun Terbit    :"); scanf(" %[^\n]s", &node->tahun);

        b++;

    if(head == NULL){
        head = node;
        curr = node;
    }else{
        curr->next = node;
        curr = node;
    }
 }
    curr->next = NULL;
    z += max;
    n += max;

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
    gotoab(0,(6*b)+3);printf("|=======================================================================================================================|");


    datahist = (struct hist*) malloc(sizeof(struct hist));
    char job[100];
    sprintf(job, "Admin menambahkan %d data baru", max);
    strcpy(datahist->aktivitas, job);

    if(headhist == NULL){
        headhist = datahist;
        currhist = datahist;
    }else{
        currhist -> next = datahist;
        currhist = datahist;
    }
    currhist -> next = NULL;
}

void deleted(){
    char idbu[30];

    gotoab(0,0); printf("|=======================================================================================================================|");
    gotoab(0,2); printf("|=======================================================================================================================|");
    gotoab(45,1);printf("Kode buku yang ingin dihapus : ");
    gotoab(60,4);printf("%s", &idbu);

    curr = head;
    struct daftar *next;
    int cek = 0;
    while(curr != NULL){
        next = (struct daftar*) malloc(sizeof(struct daftar));
        next = curr->next;

        int cmp = strcmp(curr->id, idbu);
        int ncmp = 1;

        if(curr->next !=NULL){
            ncmp = strcmp(next->id, idbu);
        }

        if (cmp == 0){
            if(curr->next !=NULL){
                head = next;
            }else{
                head = NULL;
            }
            cek = 1;
            break;

        }else if(ncmp == 0){
            curr->next = next->next;
            cek = 1;
            break;
        }

        if(curr->next != NULL){
            curr = curr->next;
        }else{
            break;
        }
    }

    if(cek == 0){
        gotoab(47,6); printf(">> Data tidak ditemukan ! <<\n");
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 13);
        gotoab(0,7); printf("|=======================================================================================================================|");
    }else{
        gotoab(47,6); printf(">> Data tidak dihapus ! <<\n");
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 13);
        gotoab(0,7); printf("|=======================================================================================================================|");

    }


    curr = head;
    while(curr != NULL);
        if(curr->next != NULL){
            curr = curr->next;
        }else{
            break;
        }
    }
    n -= 1;

    datahist = (struct hist*) malloc (sizeof(struct hist));
    char job[100];
    sprintf(job, "Admin menghapus data dengan kode buku = %s ", idbu);
    strcpy(datahist->aktivitas, job);

    if(headhist == NULL){
        headhist = datahist;
        currhist = datahist;
    }else{
        currhist -> next = datahist;
        currhist = datahist;
    }
    currhist -> next = NULL;
    kembali();


void edit(){
    int input;
    char cari[10], newval[30], buku[30], penerbit[30], pengarang[30], tahun[30];
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
    gotoab(0,0); printf("|=======================================================================================================================|");
    gotoab(0,2); printf("|=======================================================================================================================|");
    gotoab(0,11); printf("|=======================================================================================================================|");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoab(44,1);printf("               Edit Data               ");
    gotoab(47,4);printf("Data apa yang ingin di edit? \n");
    gotoab(47,5);printf("1. Judul Buku");
    gotoab(47,6);printf("2. Nama Penerbit");
    gotoab(47,7);printf("3. Nama Pengarang");
    gotoab(47,8);printf("4. Tahun Terbit");
    gotoab(44,9);printf("Pilihan");
    gotoab(47,9);printf("%d", &input);
    gotoab(47,10);printf("Masukan ID buku: ");
    gotoab(47,10);printf("%s",cari);
    search(cari);
    cls();

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
    gotoab(0,0); printf("|=======================================================================================================================|");
    gotoab(0,2); printf("|=======================================================================================================================|");
    gotoab(0,5); printf("|=======================================================================================================================|");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
    gotoab(40,1);printf("               Edit Data               ");

    if(searchEdit(cari) == 1){

        gotoab(47,4); printf("Masukan nilai baru");
        scanf(" %[^\n]s", &newval);
        switch(input){

        case 1;
            strcpy(curr->buku, newval);
            break;
        case 2;
            strcpy(curr->penerbit, newpal);
            break;
        case 3;
            strcpy(curr->pengarang, newpal);
            break;
        case 4;
            strcpy(curr->tahun, newpal);
            break;
        }
    }else{
        gotoab(47,4);printf("Data tidak ditemukan ! \n");
    }

    curr = head;
    while(curr != NULL){
        if(curr->next != NULL){
            curr = curr->next;
        }else{
            break;
        }
    }

    datahist = (struct hist*) malloc(sizeof(struct hist));
    strcpy(datahist->aktivitas, "Admin melakukan edit data");

    if(headhist == NULL){
        headhist = datahist;
        currhist = datahist;
    }else{
        currhist -> next = datahist;
        currhist = datahist;
    }
    currhist -> next = NULL;
}



